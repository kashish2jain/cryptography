"""
Decryption module
"""
from encrypt import (rsa_decrypt, dec_base, vigenere_decrypt,
                              write_to_file, di_stringify_keys,
                              readlines_from_file)

stp = ""
ktp = ""

message_blocks = readlines_from_file("./texts/cipher_text.txt")
key_blocks = readlines_from_file("./texts/cipher_key.txt")

pka, _, pkb, skb = di_stringify_keys(readlines_from_file)

for C, K_prime in zip(message_blocks, key_blocks):
    crypted_msg = rsa_decrypt(skb, C)
    crypted_key = rsa_decrypt(skb, K_prime)

    cipher_text = rsa_decrypt(pka, crypted_msg)
    key         = rsa_decrypt(pka, crypted_key)

    stp = stp + dec_base(cipher_text, 26)
    ktp = ktp + dec_base(key, 26)


message = vigenere_decrypt(stp, ktp)
print(f"Plain text: {message}")

write_to_file(message, "./texts/plain_text.txt")
