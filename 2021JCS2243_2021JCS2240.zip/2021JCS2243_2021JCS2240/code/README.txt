Instructions to run the code:

The given file is a jupyter notebook file. 
Open it via jupyter notebook and run the cells.
The data will be fetched automatically.