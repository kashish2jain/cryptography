I have attched .cc file and .exe file to the corresponding code in a source file
and also code run in online (c++ compiler)