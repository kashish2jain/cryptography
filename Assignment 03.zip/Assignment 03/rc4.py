import math
import random
import binascii

from typing import List
from pprint import pprint
from statistics import stdev
from collections import Counter

import matplotlib.pyplot as plt
plt.style.use('seaborn')


def swap(arr: List, pos_1: int, pos_2: int):
    """
    Use to swap values of the array 'arr'
    of indexes 'pos_1', 'pos_2'
    """
    temp = arr[pos_1]
    arr[pos_1] = arr[pos_2]
    arr[pos_2] = temp


def key_scheduling(key: str) -> List[int]: # Initial permutation
    """
    Method to generate the initial permutation
    """
    key = list(binascii.unhexlify(key))
    keylen = len(key)

    # s array
    s = list(range(256))

    # repeated version of key
    t = [key[i%keylen] for i in range(256)]  
    j = 0
    for i in range(256):
        j = (j + s[i] + t[i]) % 256
        swap(s, i, j)
    return s


def prga(s: List[int]) -> int:
    """
    Pseudo-random number generator
    """
    i = 0
    j = 0
    while(True):
        i = (i+1) % 256
        j = (j+s[i]) % 256
        swap(s, i, j)
        t = (s[i]+s[j]) % 256
        k = s[t]
        yield k


def rc4_key_generation(key: str) -> List[int]:
    s = key_scheduling(key)
    keystream = prga(s)
    arr = list(range(1024))
    for i in range(1024):
        arr[i] = next(keystream)
    return arr


def run_simulation():
    key = None
    with open("./key.txt", "r") as f:
        key = f.read()

    int_key = int(key, 16)
    key_size = len(key) * 4
    fixed_output_byte_size = 256
    original_key_stream = rc4_key_generation(key)

    num_of_toggled_bits = [i+1 for i in range(32)]
    output_sizes = [2**i for i in range(1,11)]
    randomness_measure = []

    for output_byte_size in output_sizes:
        n = (output_byte_size*8)-7

        randomness_values = []
        for toggled_bits in num_of_toggled_bits:
            r    = 0
            ctrs = []

            for i in range(20):
                counter_arr = [0 for i in range(256)]
                positions_toggled = random.sample(range(0,key_size), toggled_bits)

                toggled_key = int_key
                for pos in positions_toggled:
                    toggled_key = toggled_key^(1<<pos)

                toggled_hex_key = hex(toggled_key)[2:].zfill(512)
                op_keystream = rc4_key_generation(toggled_hex_key)

                binary_op_keystream       = ""
                binary_original_keystream = ""
                for j in range(output_byte_size):
                    binary_op_keystream       =  binary_op_keystream + format(op_keystream[j], "b").zfill(8)
                    binary_original_keystream =  binary_original_keystream + format(original_key_stream[j], "b").zfill(8)

                # Randomness calculation
                for index in range(n):
                    """
                    e.g. 0-7

                    if:
                        modified: 1 1 0 1 0 1 0 0
                        original: 1 1 0 1 0 1 0 0

                        counter_arr[0] += 1
                        i.e. bits from 0 to 7 in both the key-stream are SAME.
                    
                    if:
                        modified: 1 1 0 1 0 1 0 0
                        original: 1 1 0 1 0 0 0 0

                        counter_arr[4] += 1
                        i.e. bits from 0 to 7 in both the key-stream are NOT SAME.
                    """
                    counter_arr[int(binary_op_keystream[index:index+8], 2)^int(binary_original_keystream[index:index+8], 2)]+=1   

                ctr = 0
                """
                1110101
                1110001 -> 4
                """
                for item1, item2 in zip(binary_original_keystream, binary_op_keystream):
                    if item1 == item2:
                        ctr += 1
                    else:
                        continue
                ctrs.append(ctr)

                std_dev = stdev(counter_arr)
                r+=(std_dev*256)/n
            
            if output_byte_size == fixed_output_byte_size:
                # print(
                #     f"""Number of bits same after flipping: {math.ceil(sum(ctrs)/len(ctrs))}"""
                #     )
                with open(f"./keys/key_{toggled_bits}.txt", "w") as f:
                    f.write(toggled_hex_key)

            randomness_values.append(r/20)

        randomness_measure.append(randomness_values)
        print(f"Output size: {output_byte_size} bytes Done!!!!", flush=True)

    analysis = {}
    for row, os in zip(randomness_measure, output_sizes):
        one = row[0]
        two = row[-1]

        analysis[os] = (one, two)

    print("Analysis of change in randomness for 1 and 32 bits toggling(for all output sizes)")
    pprint(analysis)

    i = 1
    for num,average_randomness in enumerate(randomness_measure):
        _, ax = plt.subplots()
        ax.plot(num_of_toggled_bits , average_randomness, marker="*", label = f"{2**(num+1)} bytes")
        ax.set_title("Average Randomness Measure v/s Number of Toggled Bits (Smaller the y-value is better)")
        ax.set_xlabel("Number of Toggled Bits")
        ax.set_ylabel("Average Randomness Measure")
        ax.legend()
        osize = 2 ** i
        i += 1
        plt.savefig(f"./plots/random_{osize}", dpi=600)


def key_length_analysis(key: str, modified_keys: List[str]) -> None:
    """
    Analyse upto which initial key length
    original and modified keys are same
    """
    counts = []
    for i in range(32):
        count = 0
        for nibble1, nibble2 in zip(key, modified_keys[i]):
            if nibble1 == nibble2:
                count += 1
            else:
                break
        counts.append(count)
        print(f"For {i+1} toggled bits, initially upto {count * 4} bytes are same!!!")


if __name__ == "__main__":
    run_simulation()

    key, modified_keys = None, []
    with open("./key.txt", "r") as f:
        key = f.read()
    
    for i in range(1, 33):
        with open(f"./keys/key_{i}.txt", "r") as f:
            modified_keys.append(f.read())
    
    key_length_analysis(key, modified_keys)
    # 1: For a fixed output size, after how many bits flipping, the randomness becomes zero or
    # constant?
